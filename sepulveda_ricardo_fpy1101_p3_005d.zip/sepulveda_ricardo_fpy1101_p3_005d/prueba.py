import os 
import msvcrt
import time

cincokg=12500
quincekg=25500

pedidos=[]
total = 0
rut=[]
cln=[]
drc=[]
cmn=[]

while True:
    os.system('cls')
    print("===_Menú de Gaxplosive_===")
    print("1 Registrar pedido ")
    print("2 Listar todos los pedidos")
    print("3 Buscar pedido por rut ")
    print("4 Imprimir hoja de ruta")
    print("5 Salir del programa")
    print("==========================")
    opc = int(input("Escoja opcion: "))


    if opc==1:
        os.system('cls')
        rut = int(input("Ingrese rut del cliente: "))
        cln = input("Ingrese nombre del cliente: ")
        drc = input("Direccion del pedido: ")
        cmn = input("Comuna del pedido: ")
        cntcinco = int(input("Cuantos cilindros de 5 kg: "))
        cntquince = int(input("Cuantos cilindros de 15 kg: "))
        total = cincokg*cntcinco+quincekg*cntquince
        
        os.system('cls')
    elif opc==2:
        pass
        
    elif opc==3:
        os.system('cls')
        int(input("Ingrese rut del cliente: "))
        print(rut)
        print(cln)
        print(drc)
        print(cmn)
        print(cntcinco)
        print(cntquince)
        print(total)
        print("Presione tecla para continuar")
        msvcrt.getch()
    elif opc==4:
        pass
    else:
        os.system('cls')
        print("_____[Pedidos archivados]_____")
        time.sleep (5)
        os.system('cls')
        
        
    